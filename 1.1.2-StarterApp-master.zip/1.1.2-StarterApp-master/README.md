# 1.1.2-StarterApp
This is the starter code for PLTW 1.1.2 
